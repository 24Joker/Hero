#include "user_aimauto.h"

Data_delay_t Yaw_angle_delay;
Data_delay_t Pitch_angle_delay;

uint8_t AimAuto_Flag = 0;

uint32_t Time3_AimAuto = 0;
int16_t yaw_rec,pitch_rec,dist_rec,thelta_raw;
float yaw_speed_raw, distance_speed_raw, pitch_speed_raw;
float y_angle, p_angle, yaw_delay, y_angle_offset, p_angle_offset, yaw_speed_filter, pitch_speed_filter, distance_filter;
float pitch_delay;
float yaw_filter = 0, pitch_filter = 0, y_anglesave = 0, p_anglesave = 0;
float Camera_Yaw = 0, Camera_Pitch = 0, dist_raw = 0;
void AimAuto_Process(uint8_t* aimautobuff)//对从PC那接收的数进行处理
{
    if(aimautobuff[0] == 0xFF && aimautobuff[9] == 0xFE)
    {
        yaw_rec = ((int16_t)camera_buff[2]<<8)|((int16_t)camera_buff[1]);//yaw
        pitch_rec = ((int16_t)camera_buff[4]<<8)|((int16_t)camera_buff[3]);//pitch	
        dist_rec = ((int16_t)camera_buff[6]<<8)|((int16_t)camera_buff[5]);//距离
        thelta_raw = ((int16_t)camera_buff[8]<<8)|((int16_t)camera_buff[7]);//帧率
        y_angle = (float)yaw_rec/10.0f;
        p_angle = -(float)pitch_rec/10.0f;
        dist_raw = (float)dist_rec/10.0f;
    }
}

void aimauto_control()
{
		if(y_angle != 0/* && 开自瞄模式*/)      //脱离视野时保持当前值
			{
					yaw_speed_raw = target_speed_calc(&Yaw_PTZ_calculate_Speed,Time3_AimAuto,y_anglesave);
					distance_speed_raw = target_speed_calc(&Pitch_PTZ_calculate_Speed,Time3_AimAuto,dist_raw);
					yaw_delay = Yaw_angle_delay.gimbal_attitude_archive[Yaw_angle_delay.get_index];
					
					y_angle_offset = y_angle/2.45f;
					y_anglesave = yaw_delay+y_angle_offset;						  
					yaw_speed_filter = Kalman_Yaw_PTZ_AimAuto.filtered_value[1];
					yaw_filter = Kalman_Yaw_PTZ_AimAuto.filtered_value[0];
					distance_filter = Kalman_Distance_AimAuto.filtered_value[0];
					Camera_Yaw = yaw_filter + yaw_speed_filter * (0.14f + distance_filter/450.0f) - Yaw_Angle_Init - PTZAngle_Ref.Yaw;		
			}
					 
			if(p_angle != 0/* && 开自瞄模式*/)
			{	   
					pitch_speed_raw = target_speed_calc(&Pitch_PTZ_calculate_Speed, Time3_AimAuto, p_anglesave/*cameraopen_pitch*/);
					pitch_delay = Pitch_angle_delay.gimbal_attitude_archive[Pitch_angle_delay.get_index];
				
					p_angle_offset = p_angle / 2.60f;						  
					p_anglesave = pitch_delay + p_angle_offset;
					pitch_speed_filter = Kalman_Pitch_PTZ_AimAuto.filtered_value[1];	
					Camera_Pitch = Kalman_Pitch_PTZ_AimAuto.filtered_value[0] + distance_filter*0.1f - PTZAngle_Ref.Pitch;						
			}
}


void DATA_delay(Data_delay_t *D,float delay_object,float delay_index)  //对数据做延时处理
{  
		D->archive_index++;       //存档标志
  if (D->archive_index > 199) //系统延迟时间   
    D->archive_index = 0;
    D->gimbal_attitude_archive[D->archive_index] = delay_object;
	if(D->archive_index >= delay_index)
	{	
    D->get_index = D->archive_index - delay_index;
	}
	else
	{
	  D->get_index = D->archive_index + 200-delay_index;             //delay_index所需延时的时间
	}	
}



