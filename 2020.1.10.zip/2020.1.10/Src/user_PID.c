#include "user_PID.h"

PID Chassis_RM3508_ID1;
PID Chassis_RM3508_ID2;
PID Chassis_RM3508_ID3;
PID Chassis_RM3508_ID4;
PID Chassis_Follow;

PID_Smis PTZ_Yaw_GM6020_Position_Smis;
PID PTZ_Yaw_GM6020_Speed;
PID_Smis PTZ_Pitch_GM6020_Position_Smis;
PID PTZ_Pitch_GM6020_Speed;

PID Toggle_RM3508_Position;
PID Toggle_RM3508_Speed;
PID Friction_RM3510_Left;
PID Friction_RM3510_Right;

void PID_Init()
{
  Chassis_RM3508_ID1.Kp = 8;
  Chassis_RM3508_ID1.Ki = 0;
  Chassis_RM3508_ID1.Kd = 0;
  Chassis_RM3508_ID1.error_inter = 0;
  Chassis_RM3508_ID1.error_last = 0;
  Chassis_RM3508_ID1.error_now = 0;
  Chassis_RM3508_ID1.pid_out = 0;
  Chassis_RM3508_ID1.limit = 10000;

  Chassis_RM3508_ID2.Kp = 8;
  Chassis_RM3508_ID2.Ki = 0;
  Chassis_RM3508_ID2.Kd = 0;
  Chassis_RM3508_ID2.error_inter = 0;
  Chassis_RM3508_ID2.error_last = 0;
  Chassis_RM3508_ID2.error_now = 0;
  Chassis_RM3508_ID2.pid_out = 0;
  Chassis_RM3508_ID2.limit = 10000;

  Chassis_RM3508_ID3.Kp = 8;
  Chassis_RM3508_ID3.Ki = 0;
  Chassis_RM3508_ID3.Kd = 0;
  Chassis_RM3508_ID3.error_inter = 0;
  Chassis_RM3508_ID3.error_last = 0;
  Chassis_RM3508_ID3.error_now = 0;
  Chassis_RM3508_ID3.pid_out = 0;
  Chassis_RM3508_ID3.limit = 10000;

  Chassis_RM3508_ID4.Kp = 8;
  Chassis_RM3508_ID4.Ki = 0;
  Chassis_RM3508_ID4.Kd = 0;
  Chassis_RM3508_ID4.error_inter = 0;
  Chassis_RM3508_ID4.error_last = 0;
  Chassis_RM3508_ID4.error_now = 0;
  Chassis_RM3508_ID4.pid_out = 0;
  Chassis_RM3508_ID4.limit = 10000;

  PTZ_Yaw_GM6020_Position_Smis.Kp = 10;
  PTZ_Yaw_GM6020_Position_Smis.Ki = 0.01;
  PTZ_Yaw_GM6020_Position_Smis.Kd = 0.2;
  PTZ_Yaw_GM6020_Position_Smis.error_inter = 0;
  PTZ_Yaw_GM6020_Position_Smis.error_now = 0;
  PTZ_Yaw_GM6020_Position_Smis.pid_out = 0;
  PTZ_Yaw_GM6020_Position_Smis.limit = 10000;

  PTZ_Yaw_GM6020_Speed.Kp = 200;
  PTZ_Yaw_GM6020_Speed.Ki = 0.1;
  PTZ_Yaw_GM6020_Speed.Kd = 30;
  PTZ_Yaw_GM6020_Speed.error_inter = 0;
  PTZ_Yaw_GM6020_Speed.error_last = 0;
  PTZ_Yaw_GM6020_Speed.error_now = 0;
  PTZ_Yaw_GM6020_Speed.pid_out = 0;
  PTZ_Yaw_GM6020_Speed.limit = 10000;

  PTZ_Pitch_GM6020_Position_Smis.Kp = 0.45;
  PTZ_Pitch_GM6020_Position_Smis.Ki = 0.5;
  PTZ_Pitch_GM6020_Position_Smis.Kd = 0.2;
  PTZ_Pitch_GM6020_Position_Smis.error_inter = 0;
  PTZ_Pitch_GM6020_Position_Smis.error_now = 0;
  PTZ_Pitch_GM6020_Position_Smis.pid_out = 0;
  PTZ_Pitch_GM6020_Position_Smis.limit = 10000;

  PTZ_Pitch_GM6020_Speed.Kp = 330;
  PTZ_Pitch_GM6020_Speed.Ki = 0.1;
  PTZ_Pitch_GM6020_Speed.Kd = 40;
  PTZ_Pitch_GM6020_Speed.error_inter = 0;
  PTZ_Pitch_GM6020_Speed.error_last = 0;
  PTZ_Pitch_GM6020_Speed.error_now = 0;
  PTZ_Pitch_GM6020_Speed.pid_out = 0;
  PTZ_Pitch_GM6020_Speed.limit = 10000;

  Toggle_RM3508_Position.Kp = 8;
  Toggle_RM3508_Position.Ki = 0;
  Toggle_RM3508_Position.Kd = 0;
  Toggle_RM3508_Position.error_inter = 0;
  Toggle_RM3508_Position.error_last = 0;
  Toggle_RM3508_Position.error_now = 0;
  Toggle_RM3508_Position.pid_out = 0;
  Toggle_RM3508_Position.limit = 10000;

  Toggle_RM3508_Speed.Kp = 8;
  Toggle_RM3508_Speed.Ki = 0;
  Toggle_RM3508_Speed.Kd = 0;
  Toggle_RM3508_Speed.error_inter = 0;
  Toggle_RM3508_Speed.error_last = 0;
  Toggle_RM3508_Speed.error_now = 0;
  Toggle_RM3508_Speed.pid_out = 0;
  Toggle_RM3508_Speed.limit = 10000;

  Friction_RM3510_Left.Kp = 8;
  Friction_RM3510_Left.Ki = 0;
  Friction_RM3510_Left.Kd = 0;
  Friction_RM3510_Left.error_inter = 0;
  Friction_RM3510_Left.error_last = 0;
  Friction_RM3510_Left.error_now = 0;
  Friction_RM3510_Left.pid_out = 0;
  Friction_RM3510_Left.limit = 10000;

  Friction_RM3510_Right.Kp = 8;
  Friction_RM3510_Right.Ki = 0;
  Friction_RM3510_Right.Kd = 0;
  Friction_RM3510_Right.error_inter = 0;
  Friction_RM3510_Right.error_last = 0;
  Friction_RM3510_Right.error_now = 0;
  Friction_RM3510_Right.pid_out = 0;
  Friction_RM3510_Right.limit = 10000;
  
  Chassis_Follow.Kp = 5;
  Chassis_Follow.Ki = 0;
  Chassis_Follow.Kd = 0;
  Chassis_Follow.error_inter = 0;
  Chassis_Follow.error_last = 0;
  Chassis_Follow.error_now = 0;
  Chassis_Follow.pid_out = 0;
  Chassis_Follow.limit = 10000;
}


void PID_Clear()
{
  Chassis_RM3508_ID1.Kp = 0;
  Chassis_RM3508_ID1.Ki = 0;
  Chassis_RM3508_ID1.Kd = 0;
  Chassis_RM3508_ID2.Kp = 0;
  Chassis_RM3508_ID2.Ki = 0;
  Chassis_RM3508_ID2.Kd = 0;
  Chassis_RM3508_ID3.Kp = 0;
  Chassis_RM3508_ID3.Ki = 0;
  Chassis_RM3508_ID3.Kd = 0;
  Chassis_RM3508_ID4.Kp = 0;
  Chassis_RM3508_ID4.Ki = 0;
  Chassis_RM3508_ID4.Kd = 0;
  Chassis_Follow.Kp = 0;
  Chassis_Follow.Ki = 0;
  Chassis_Follow.Kd = 0;
  PTZ_Yaw_GM6020_Position_Smis.Kp = 0;
  PTZ_Yaw_GM6020_Position_Smis.Ki = 0;
  PTZ_Yaw_GM6020_Position_Smis.Kd = 0;
  PTZ_Yaw_GM6020_Speed.Kp = 0;
  PTZ_Yaw_GM6020_Speed.Ki = 0;
  PTZ_Yaw_GM6020_Speed.Kd = 0;
  PTZ_Pitch_GM6020_Position_Smis.Kp = 0;
  PTZ_Pitch_GM6020_Position_Smis.Ki = 0;
  PTZ_Pitch_GM6020_Position_Smis.Kd = 0;
  PTZ_Pitch_GM6020_Speed.Kp = 0;
  PTZ_Pitch_GM6020_Speed.Ki = 0;
  PTZ_Pitch_GM6020_Speed.Kd = 0;
  Toggle_RM3508_Position.Kp = 0;
  Toggle_RM3508_Position.Ki = 0;
  Toggle_RM3508_Position.Kd = 0;
  Toggle_RM3508_Speed.Kp = 0;
  Toggle_RM3508_Speed.Ki = 0;
  Toggle_RM3508_Speed.Kd = 0;
  Friction_RM3510_Left.Kp = 0;
  Friction_RM3510_Left.Ki = 0;
  Friction_RM3510_Left.Kd = 0;
  Friction_RM3510_Right.Kp = 0;
  Friction_RM3510_Right.Ki = 0;
  Friction_RM3510_Right.Kd = 0;
}
