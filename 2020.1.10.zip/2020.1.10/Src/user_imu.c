#include "user_imu.h"

int yaw_usart_count = 0;
volatile  float pitch_usart_angle = 0;
volatile  float yaw_usart_angle = 0;
volatile  float yaw_usart_temp = 0;
volatile  float last_yaw_usart_temp = 0;

static  float gyro_y = 0;
static  float gyro_z = 0;

float gyro_usart_y = 0;
float gyro_usart_z = 0;

int data_index = 0;
void Usart_Imu_Data_Process(const uint8_t *ucRxBuffer)
{
	/*****************搜索包头*******************/
    if(ucRxBuffer[0] == 0x5A)
    {
        data_index=0;
    }
    else if(ucRxBuffer[data_index] != 0x5A)
    {		
        data_index++;
        if(data_index > 40)data_index = 0;
    }
	/*********************数据处理***************/
    if(ucRxBuffer[data_index + 6] == 0xB0)  //角速度
    {
        gyro_y = -((int16_t)(ucRxBuffer[data_index + 8]<< 8 | ucRxBuffer[data_index + 7])) / 10.0f;//P轴
        gyro_z = ((int16_t)(ucRxBuffer[data_index + 12]<< 8 | ucRxBuffer[data_index + 11])) / 10.0f;//Y轴
        gyro_usart_y = gyro_y;
        gyro_usart_z = gyro_z;
    }
    if(ucRxBuffer[data_index + 13] == 0xD0)  //角度
    {
        pitch_usart_angle = ((int16_t)(ucRxBuffer[data_index + 17]<< 8 | ucRxBuffer[data_index + 16])) / 100.0f;
        yaw_usart_temp = ((int16_t)(ucRxBuffer[data_index + 19]<< 8 | ucRxBuffer[data_index + 18])) / 10.0f;
        if(yaw_usart_temp - last_yaw_usart_temp >= 300)  //yaw轴角度经过处理后变成连续的
        {
            yaw_usart_count--;
        }
        else if (yaw_usart_temp - last_yaw_usart_temp <= -300)
        {
            yaw_usart_count++;
        }
        yaw_usart_angle = -(yaw_usart_temp + yaw_usart_count*360);  //roll轴角度
        last_yaw_usart_temp = yaw_usart_temp;
    }
}