/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "RM_LIB.h"
#include "user_all.h"
uint32_t Time3_Count = 0;
float Yaw_Angle_except = 0, Pitch_Angle_except;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
 
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern CAN_HandleTypeDef hcan1;
extern CAN_HandleTypeDef hcan2;
extern TIM_HandleTypeDef htim3;
extern DMA_HandleTypeDef hdma_uart5_rx;
extern DMA_HandleTypeDef hdma_usart1_rx;
extern DMA_HandleTypeDef hdma_usart2_rx;
extern UART_HandleTypeDef huart5;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
/* USER CODE BEGIN EV */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if(htim->Instance == TIM3)
  {
    ++Time3_AimAuto;
		++Time3_Count;
    if(Time3_Count > 3000)
      Time3_Count = 3000;
    if(Time3_Count <= 2000)
    {
			///////��ʼ��ҡ��ʧ��///////
			PTZAngle_Ref.Pitch = 0;
			PTZAngle_Ref.Yaw = 0;
			ChassisSpeed_Ref.forward_back_ref = 0;
			ChassisSpeed_Ref.left_right_ref = 0;
      ////////Pitch��ʼ��////////
      PID_Control_Smis(Rx_PTZ_Pitch_GM6020.Angle, PTZ_Pitch_Mid, &PTZ_Pitch_GM6020_Position_Smis, Rx_PTZ_Pitch_GM6020.Speed);
      limit(PTZ_Pitch_GM6020_Position_Smis.pid_out, 350, -350);
      PID_Control(Rx_PTZ_Pitch_GM6020.Speed, PTZ_Pitch_GM6020_Position_Smis.pid_out, &PTZ_Pitch_GM6020_Speed);
      limit(PTZ_Pitch_GM6020_Speed.pid_out, 3000, -3000);
      /////////Yaw��ʼ��/////////
      PID_Control_Smis(Rx_PTZ_Yaw_GM6020.Angle, PTZ_Yaw_Mid, &PTZ_Yaw_GM6020_Position_Smis, Rx_PTZ_Yaw_GM6020.Speed);
//      PTZ_Yaw_GM6020_Position_Smis.pid_out = -PTZ_Yaw_GM6020_Position_Smis.pid_out;
      limit(PTZ_Yaw_GM6020_Position_Smis.pid_out, 350, -350);
      PID_Control(Rx_PTZ_Yaw_GM6020.Speed, PTZ_Yaw_GM6020_Position_Smis.pid_out, &PTZ_Yaw_GM6020_Speed);
//      PTZ_Yaw_GM6020_Speed.pid_out = -PTZ_Yaw_GM6020_Speed.pid_out;
      limit(PTZ_Yaw_GM6020_Speed.pid_out, 3000, -3000);
			//////��¼����������//////
      Yaw_Angle_Init = yaw_usart_angle;
			PTZ_Buff[0] = (int16_t)PTZ_Yaw_GM6020_Speed.pid_out >> 8;
	    PTZ_Buff[1] = (int16_t)PTZ_Yaw_GM6020_Speed.pid_out;
      PTZ_Buff[2] = (int16_t)PTZ_Pitch_GM6020_Speed.pid_out >> 8;
	    PTZ_Buff[3] = (int16_t)PTZ_Pitch_GM6020_Speed.pid_out;
    }
    else
    {
      Yaw_Angle_except = Yaw_Angle_Init + PTZAngle_Ref.Yaw;//得到Yaw期望
      Pitch_Angle_except = PTZ_Pitch_Mid + PTZAngle_Ref.Pitch;//得到Pitch期望
			limit(Pitch_Angle_except, PTZ_Pitch_Max, PTZ_Pitch_Min);//Pitch限幅
      /***********��̨����***********/
			if(AimAuto_Flag == 0)//�����������
			{
				////////Pitch����////////
				PID_Control_Smis(Rx_PTZ_Pitch_GM6020.Angle, Pitch_Angle_except, &PTZ_Pitch_GM6020_Position_Smis, Rx_PTZ_Pitch_GM6020.Speed);
				limit(PTZ_Pitch_GM6020_Position_Smis.pid_out, 350, -350);
				PID_Control(Rx_PTZ_Pitch_GM6020.Speed, PTZ_Pitch_GM6020_Position_Smis.pid_out, &PTZ_Pitch_GM6020_Speed);
				limit(PTZ_Pitch_GM6020_Speed.pid_out, 30000, -30000);
				/////////Yaw����/////////
				PID_Control_Smis(yaw_usart_angle, Yaw_Angle_except, &PTZ_Yaw_GM6020_Position_Smis, Rx_PTZ_Yaw_GM6020.Speed);
				PTZ_Yaw_GM6020_Position_Smis.pid_out = -PTZ_Yaw_GM6020_Position_Smis.pid_out;
				limit(PTZ_Yaw_GM6020_Position_Smis.pid_out, 350, -350);
				PID_Control(Rx_PTZ_Yaw_GM6020.Speed, PTZ_Yaw_GM6020_Position_Smis.pid_out, &PTZ_Yaw_GM6020_Speed);
				limit(PTZ_Yaw_GM6020_Speed.pid_out, 30000, -30000);
			}
			else
			{
				////////��������////////
//			DATA_delay(&Yaw_angle_delay,yaw_usart_angle,28);//28
//			DATA_delay(&Pitch_angle_delay,pitch_usart_angle,1);//30
				//////�������ݴ���/////
				aimauto_control();
				/////////Pitch////////
				PID_Control_Smis(Rx_PTZ_Pitch_GM6020.Angle, Camera_Pitch, &PTZ_Pitch_GM6020_Position_Smis, Rx_PTZ_Pitch_GM6020.Speed);
				limit(PTZ_Pitch_GM6020_Position_Smis.pid_out, 350, -350);
				PID_Control(Rx_PTZ_Pitch_GM6020.Speed, PTZ_Pitch_GM6020_Position_Smis.pid_out, &PTZ_Pitch_GM6020_Speed);
				limit(PTZ_Pitch_GM6020_Speed.pid_out, 30000, -30000);
				/////////Yaw////////
				PID_Control_Smis(yaw_usart_angle, Camera_Yaw, &PTZ_Yaw_GM6020_Position_Smis, Rx_PTZ_Yaw_GM6020.Speed);
				PTZ_Yaw_GM6020_Position_Smis.pid_out = -PTZ_Yaw_GM6020_Position_Smis.pid_out;
				limit(PTZ_Yaw_GM6020_Position_Smis.pid_out, 350, -350);
				PID_Control(Rx_PTZ_Yaw_GM6020.Speed, PTZ_Yaw_GM6020_Position_Smis.pid_out, &PTZ_Yaw_GM6020_Speed);
				limit(PTZ_Yaw_GM6020_Speed.pid_out, 30000, -30000);
			}
			///////��̨��Ϣ����///////
				PTZ_Buff[0] = (int16_t)PTZ_Yaw_GM6020_Speed.pid_out >> 8;
				PTZ_Buff[1] = (int16_t)PTZ_Yaw_GM6020_Speed.pid_out;
				PTZ_Buff[2] = (int16_t)PTZ_Pitch_GM6020_Speed.pid_out >> 8;
				PTZ_Buff[3] = (int16_t)PTZ_Pitch_GM6020_Speed.pid_out;
      
      /***********���̿���***********/
			PID_Control(Rx_PTZ_Yaw_GM6020.Angle, PTZ_Yaw_Mid, &Chassis_Follow);
			limit(Chassis_Follow.pid_out, 5000, -5000);
			ChassisSpeed_Ref.rotate_ref = Chassis_Follow.pid_out;
			PID_Expect(&Chassis_Speed_Expect, &ChassisSpeed_Ref);
      PID_Control(Rx_Chassis_RM3508_ID1.Speed, Chassis_Speed_Expect.Chassis_Motor_PID_Expect_1, &Chassis_RM3508_ID1);
      PID_Control(Rx_Chassis_RM3508_ID2.Speed, Chassis_Speed_Expect.Chassis_Motor_PID_Expect_2, &Chassis_RM3508_ID2);
      PID_Control(Rx_Chassis_RM3508_ID3.Speed, Chassis_Speed_Expect.Chassis_Motor_PID_Expect_3, &Chassis_RM3508_ID3);
      PID_Control(Rx_Chassis_RM3508_ID4.Speed, Chassis_Speed_Expect.Chassis_Motor_PID_Expect_4, &Chassis_RM3508_ID4);
      limit(Chassis_RM3508_ID1.pid_out, 16384, -16384);
      limit(Chassis_RM3508_ID2.pid_out, 16384, -16384);
      limit(Chassis_RM3508_ID3.pid_out, 16384, -16384);
      limit(Chassis_RM3508_ID4.pid_out, 16384, -16384);
      Chassis_Buff[0] = (int16_t)Chassis_RM3508_ID1.pid_out >> 8;
      Chassis_Buff[1] = (int16_t)Chassis_RM3508_ID1.pid_out;
      Chassis_Buff[2] = (int16_t)Chassis_RM3508_ID2.pid_out >> 8;
      Chassis_Buff[3] = (int16_t)Chassis_RM3508_ID2.pid_out;
      Chassis_Buff[4] = (int16_t)Chassis_RM3508_ID3.pid_out >> 8;
      Chassis_Buff[5] = (int16_t)Chassis_RM3508_ID3.pid_out;
      Chassis_Buff[6] = (int16_t)Chassis_RM3508_ID4.pid_out >> 8;
      Chassis_Buff[7] = (int16_t)Chassis_RM3508_ID4.pid_out;
      
    }
    /***********��Ϣ���***********/
    CAN1_Send_Msg(0x200, Chassis_Buff);//CAN1 ID1-4
    CAN1_Send_Msg(0x1ff, PTZ_Buff);//CAN1 ID5-8
//    CAN2_Send_Msg(0x200, Toggle_Buff);
  }
}
/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */ 
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */

  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles DMA1 stream0 global interrupt.
  */
void DMA1_Stream0_IRQHandler(void)
{
  /* USER CODE BEGIN DMA1_Stream0_IRQn 0 */

  /* USER CODE END DMA1_Stream0_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_uart5_rx);
  /* USER CODE BEGIN DMA1_Stream0_IRQn 1 */

  /* USER CODE END DMA1_Stream0_IRQn 1 */
}

/**
  * @brief This function handles DMA1 stream5 global interrupt.
  */
void DMA1_Stream5_IRQHandler(void)
{
  /* USER CODE BEGIN DMA1_Stream5_IRQn 0 */

  /* USER CODE END DMA1_Stream5_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_usart2_rx);
  /* USER CODE BEGIN DMA1_Stream5_IRQn 1 */

  /* USER CODE END DMA1_Stream5_IRQn 1 */
}

/**
  * @brief This function handles CAN1 RX0 interrupts.
  */
void CAN1_RX0_IRQHandler(void)
{
  /* USER CODE BEGIN CAN1_RX0_IRQn 0 */
  CAN1_Receive_Msg(CAN1_buff);
  switch(CAN1_Rx.StdId)
  {
    case 0x201:
      RM3508_Receive(&Rx_Chassis_RM3508_ID1, CAN1_buff);
      break;
    case 0x202:
      RM3508_Receive(&Rx_Chassis_RM3508_ID2, CAN1_buff);
      break;
    case 0x203:
      RM3508_Receive(&Rx_Chassis_RM3508_ID3, CAN1_buff);
      break;
    case 0x204:
      RM3508_Receive(&Rx_Chassis_RM3508_ID4, CAN1_buff);
      break;
    case 0x205:
      GM6020_Receive(&Rx_PTZ_Yaw_GM6020, CAN1_buff);
      break;
    case 0x206:
      GM6020_Receive(&Rx_PTZ_Pitch_GM6020, CAN1_buff);
      break;
    default:
      break;
  }
  /* USER CODE END CAN1_RX0_IRQn 0 */
  HAL_CAN_IRQHandler(&hcan1);
  /* USER CODE BEGIN CAN1_RX0_IRQn 1 */

  /* USER CODE END CAN1_RX0_IRQn 1 */
}

/**
  * @brief This function handles TIM3 global interrupt.
  */
void TIM3_IRQHandler(void)
{
  /* USER CODE BEGIN TIM3_IRQn 0 */

  /* USER CODE END TIM3_IRQn 0 */
  HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */

  /* USER CODE END TIM3_IRQn 1 */
}

/**
  * @brief This function handles USART1 global interrupt.
  */
void USART1_IRQHandler(void)
{
  /* USER CODE BEGIN USART1_IRQn 0 */
  uint32_t temp;
  if(__HAL_UART_GET_FLAG(&huart1, UART_FLAG_IDLE) != RESET)
  {

      __HAL_UART_CLEAR_IDLEFLAG(&huart1);
      (void)huart1.Instance->SR;
      (void)huart1.Instance->DR;

      HAL_UART_DMAStop(&huart1);
		  
      temp = hdma_usart1_rx.Instance->NDTR;
		  HAL_UART_Receive_DMA(&huart1, usart1_dma_bf, BUFLEN1);
		  if(temp == 12)
			{
				Remote_Rx(usart1_dma_bf);
			}
	}
  #if 0
  /* USER CODE END USART1_IRQn 0 */
  HAL_UART_IRQHandler(&huart1);
  /* USER CODE BEGIN USART1_IRQn 1 */
  #endif
  /* USER CODE END USART1_IRQn 1 */
}

/**
  * @brief This function handles USART2 global interrupt.
  */
void USART2_IRQHandler(void)
{
  /* USER CODE BEGIN USART2_IRQn 0 */
  uint32_t temp;
  if(__HAL_UART_GET_FLAG(&huart2, UART_FLAG_IDLE) != RESET)
  {

      __HAL_UART_CLEAR_IDLEFLAG(&huart2);
      (void)huart2.Instance->SR;
      (void)huart2.Instance->DR;

      HAL_UART_DMAStop(&huart2);
		  
      temp = hdma_usart2_rx.Instance->NDTR;
		  HAL_UART_Receive_DMA(&huart2, usart2_dma_bf, BUFLEN2);
      Usart_Imu_Data_Process(usart2_dma_bf);
	}
  #if 0
  /* USER CODE END USART2_IRQn 0 */
  HAL_UART_IRQHandler(&huart2);
  /* USER CODE BEGIN USART2_IRQn 1 */
  #endif
  /* USER CODE END USART2_IRQn 1 */
}

/**
  * @brief This function handles UART5 global interrupt.
  */
void UART5_IRQHandler(void)
{
  /* USER CODE BEGIN UART5_IRQn 0 */
  if((__HAL_UART_GET_FLAG(&huart5, UART_FLAG_IDLE) != RESET) && __HAL_UART_GET_IT_SOURCE(&huart5, UART_IT_IDLE) != RESET)//是否触发IDLE中断
	 {
			__HAL_UART_CLEAR_IDLEFLAG(&huart5);  //ÿ�ζ�Ҫ��������ж�
				(void)huart5.Instance->SR;
				(void)huart5.Instance->DR;
			HAL_UART_DMAStop(&huart5);    //ֹͣDMA����
			HAL_UART_Receive_DMA(&huart5, camera_buff, MINIPC_BUFFLEN);
			AimAuto_Process(camera_buff);
			yaw_speed_raw = target_speed_calc(&Yaw_PTZ_calculate_Speed,Time3_AimAuto,y_anglesave);
			distance_speed_raw = target_speed_calc(&Pitch_PTZ_calculate_Speed,Time3_AimAuto,dist_raw);
		//  if(camera_buff[0]==0xFF&&camera_buff[9]==0xFE)            
	  //  {
		// 	 HAL_UART_Receive_DMA(&huart5, camera_buff, MINIPC_BUFFLEN);
	  //  }
		//  else
		//  {
		// 	 HAL_UART_Receive_DMA(&huart5, camera_buff, MINIPC_BUFFLEN);
		//  }
	 }
  /* USER CODE END UART5_IRQn 0 */
  HAL_UART_IRQHandler(&huart5);
  /* USER CODE BEGIN UART5_IRQn 1 */

  /* USER CODE END UART5_IRQn 1 */
}

/**
  * @brief This function handles DMA2 stream2 global interrupt.
  */
void DMA2_Stream2_IRQHandler(void)
{
  /* USER CODE BEGIN DMA2_Stream2_IRQn 0 */

  /* USER CODE END DMA2_Stream2_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_usart1_rx);
  /* USER CODE BEGIN DMA2_Stream2_IRQn 1 */

  /* USER CODE END DMA2_Stream2_IRQn 1 */
}

/**
  * @brief This function handles CAN2 RX1 interrupt.
  */
void CAN2_RX1_IRQHandler(void)
{
  /* USER CODE BEGIN CAN2_RX1_IRQn 0 */
  CAN2_Receive_Msg(CAN2_buff);
  switch(CAN2_Rx.StdId)
  {
    case 0x201:
      RM3508_Receive(&Rx_Toggle_RM3508, CAN2_buff);
      break;
    case 0x202:
      RM3510_Receive(&Rx_Friction_RM3510_Left, CAN2_buff);
      break;
    case 0x203:
      RM3510_Receive(&Rx_Friction_RM3510_Right, CAN2_buff);
      break;
    default:
      break;
  }
  /* USER CODE END CAN2_RX1_IRQn 0 */
  HAL_CAN_IRQHandler(&hcan2);
  /* USER CODE BEGIN CAN2_RX1_IRQn 1 */

  /* USER CODE END CAN2_RX1_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
