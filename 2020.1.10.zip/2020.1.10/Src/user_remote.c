#include "user_remote.h"
ChassisSpeed_Ref_t ChassisSpeed_Ref;
PTZAngle_Ref_t PTZAngle_Ref;
Chassis_Motor_PID_Expect Chassis_Speed_Expect;
int Last_S1 = 0, Remote_Firction_Flag = 0;
uint8_t Friction_Wheel_State = FRICTION_WHEEL_OFF;
uint8_t Mouse_Right_Count = 0;
uint8_t Wriggle_Action_Count = 0, Wriggle_Action_Flag = 0; 
float Yaw_Angle_Init = 0;//记录初始化完成后陀螺仪的值
void RemoteControlProcess(Remote *rc)
{
	ChassisSpeed_Ref.forward_back_ref = (RC_CtrlData.rc.ch1 - (int16_t)REMOTE_CONTROLLER_STICK_OFFSET) * STICK_TO_CHASSIS_SPEED_REF_FACT;
	ChassisSpeed_Ref.left_right_ref = (RC_CtrlData.rc.ch0 - (int16_t)REMOTE_CONTROLLER_STICK_OFFSET) * STICK_TO_CHASSIS_SPEED_REF_FACT;
//	ChassisSpeed_Ref.rotate_ref = (rc->ch2 - (int16_t)REMOTE_CONTROLLER_STICK_OFFSET) * STICK_TO_CHASSIS_ROTATE_FACT;//直接将遥控器付给地盘(不通过云台)
	PTZAngle_Ref.Pitch +=  (float)(rc->ch3 - REMOTE_CONTROLLER_STICK_OFFSET) * STICK_TO_PITCH_ANGLE_INC_FACT;
	PTZAngle_Ref.Yaw += (float)(rc->ch2 - (int16_t)REMOTE_CONTROLLER_STICK_OFFSET) * STICK_TO_YAW_ANGLE_INC_FACT;
//  limit(PTZAngle_Ref.Pitch);        //Pitch轴限幅
    if(Last_S1 == 3 && RC_CtrlData.rc.s1 == 1)
        Remote_Firction_Flag = ~Remote_Firction_Flag;
    if(Remote_Firction_Flag)
    {
        //开启摩擦轮    
    }
    else
    {
        //关闭摩擦轮
    }
    if(Remote_Firction_Flag && Last_S1 == 3 && RC_CtrlData.rc.s1 == 2)
    {
        //拨弹
    }

}

void MouseKeyControlProcess(Mouse *mouse,Key_t key,Key_t Lastkey)
{
    static int Right_Click_delay = 0;
    /*******鼠标控制******/
    //////////云台/////////
    limit(mouse->x, 43, -43);
    limit(mouse->y, 120, -120);
    PTZAngle_Ref.Yaw += mouse->x * MOUSE_TO_YAW_ANGLE_INC_FACT;
	PTZAngle_Ref.Pitch -= mouse->y * MOUSE_TO_PITCH_ANGLE_INC_FACT;
//    limit()       //Pitch限幅
    //////////发射/////////
    switch(Friction_Wheel_State)
    {
        case FRICTION_WHEEL_OFF:
            if(mouse->last_press_r == 0 && mouse->press_r == 1)
            {
                //开启摩擦轮
                Friction_Wheel_State = FRICTION_WHEEL_ON;
            }
            break;
        case FRICTION_WHEEL_ON:
        {
            if(mouse->press_r == 0)
            {
                Mouse_Right_Count = 0;
            }
            if(mouse->press_r == 1)
            {
                ++Mouse_Right_Count;
                if(Mouse_Right_Count >= 120)
                {
                    //关闭摩擦轮
                    Friction_Wheel_State = 0;
                }
            }
            if(mouse->press_l == 1 && mouse->last_press_l == 0)
            {
                //拨弹
            }
            break;
        }
    }
    /*******鼠键盘控制******/
    //////////移动/////////
    if(key.W)
    {
        //向前走
    }
    else if(key.S)
    {
        //向后走
    }
    else
    {
        ChassisSpeed_Ref.forward_back_ref = 0;
    }
    if(key.A)
    {
        //向左走
    }
    else if(key.D)
    {
        //向右走
    }
    else
    {
        ChassisSpeed_Ref.left_right_ref = 0;
    }
    if(key.E)
    {
			
    }
}

void STOPControlProcess()
{
    PID_Clear();
}
