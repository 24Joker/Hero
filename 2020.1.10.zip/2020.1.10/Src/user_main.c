#include "user_main.h"

uint8_t usart1_dma_bf[BUFLEN1];
uint8_t usart2_dma_bf[BUFLEN2];
uint8_t camera_buff[MINIPC_BUFFLEN];

RM3508_TypeDef Rx_Chassis_RM3508_ID1;
RM3508_TypeDef Rx_Chassis_RM3508_ID2;
RM3508_TypeDef Rx_Chassis_RM3508_ID3;
RM3508_TypeDef Rx_Chassis_RM3508_ID4;
RM3508_TypeDef Rx_Toggle_RM3508;
RM3510_TypeDef Rx_Friction_RM3510_Left;
RM3510_TypeDef Rx_Friction_RM3510_Right;
GM6020_TypeDef Rx_PTZ_Yaw_GM6020;
GM6020_TypeDef Rx_PTZ_Pitch_GM6020;

uint8_t Chassis_Buff[8];
uint8_t PTZ_Buff[8];
uint8_t Toggle_Buff[8];
