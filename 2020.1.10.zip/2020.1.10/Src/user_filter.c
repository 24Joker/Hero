#include "user_filter.h"

kalman_filter_init_t Ch2_Init = 
{
    .P_data = {2, 0, 0, 2},     // 协方差矩阵
    .A_data = {1, 0.001, 0, 1}, // 预测矩阵 （采样时间）
    .H_data = {2, 0, 0, 1},     // 传感器测量数据矩阵
    .Q_data = {0.1, 0, 0, 0.1}, // 外部的不确定性（不确定性）
    .R_data = {0.1, 0.1, 0.1, 0.1}, // 传感器测量方差（采集数据方差）
    .E_data = {1, 0, 0, 1}      // 单位矩阵
//    .P_data = {1,1,1,1},           // 协方差矩阵
//    .A_data = {1,0.001,0,1},        // 预测矩阵 （采样时间）
//    .H_data = {1, 0, 0, 1}, 					// 传感器测量数据矩阵
//    .Q_data = {0.01,0,0,0.01},           // 外部的不确定性（不确定性）
//    .R_data = {0.2879,0.0213,0.0213,1.8787},      // 传感器测量方差（采集数据方差）
//    .E_data = {1,0,0,1}            // 单位矩阵
};

kalman_filter_init_t Kalman_Yaw_PTZ_AimAuto = 
{
    .P_data = {2, 0, 0, 2},     // 协方差矩阵
    .A_data = {1, 0.001, 0, 1}, // 预测矩阵 （采样时间）
    .H_data = {2, 0, 0, 1},     // 传感器测量数据矩阵
    .Q_data = {0.1, 0, 0, 0.1}, // 外部的不确定性（不确定性）
    .R_data = {0.1, 0.1, 0.1, 0.1}, // 传感器测量方差（采集数据方差）
    .E_data = {1, 0, 0, 1}      // 单位矩阵
};


kalman_filter_init_t Kalman_Pitch_PTZ_AimAuto = 
{
    .P_data = {2, 0, 0, 2},     // 协方差矩阵
    .A_data = {1, 0.001, 0, 1}, // 预测矩阵 （采样时间）
    .H_data = {2, 0, 0, 1},     // 传感器测量数据矩阵
    .Q_data = {0.1, 0, 0, 0.1}, // 外部的不确定性（不确定性）
    .R_data = {0.1, 0.1, 0.1, 0.1}, // 传感器测量方差（采集数据方差）
    .E_data = {1, 0, 0, 1}      // 单位矩阵
};

kalman_filter_init_t Kalman_Distance_AimAuto =
{
	.P_data = {2, 0, 0, 2},     // 协方差矩阵
	.A_data = {1, 0.001, 0, 1}, // 预测矩阵 （采样时间）
	.H_data = {2, 0, 0, 1},     // 传感器测量数据矩阵
	.Q_data = {0.1, 0, 0, 0.1}, // 外部的不确定性（不确定性）
	.R_data = {0.1, 0.1, 0.1, 0.1}, // 传感器测量方差（采集数据方差）
	.E_data = {1, 0, 0, 1}      // 单位矩阵
};

speed_calc_data_t Yaw_PTZ_calculate_Speed;
speed_calc_data_t Pitch_PTZ_calculate_Speed;
speed_calc_data_t Distance_PTZ_calculate_Speed;

void All_Kalman_Filter_Init()
{
    kalman_filter_init(&Kalman_Yaw_PTZ_AimAuto);
    kalman_filter_init(&Kalman_Pitch_PTZ_AimAuto);
}
