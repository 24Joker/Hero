#include "RM_LIB.h"
#include "stm32f4xx_hal.h"

extern PID Chassis_RM3508_ID1;
extern PID Chassis_RM3508_ID2;
extern PID Chassis_RM3508_ID3;
extern PID Chassis_RM3508_ID4;
extern PID Chassis_Follow;

extern PID_Smis PTZ_Yaw_GM6020_Position_Smis;
extern PID PTZ_Yaw_GM6020_Speed;
extern PID_Smis PTZ_Pitch_GM6020_Position_Smis;
extern PID PTZ_Pitch_GM6020_Speed;

extern PID Toggle_RM3508_Position;
extern PID Toggle_RM3508_Speed;
extern PID Friction_RM3510_Left;
extern PID Friction_RM3510_Right;

void PID_Init(void);
void PID_Clear(void);
