

#ifndef __USART_IMU_H
#define __USART_IMU_H
#include "RM_LIB.h"
#include "stm32f4xx_hal.h"
#include "usart.h"


extern int yaw_usart_count;
extern volatile  float pitch_usart_angle;
extern volatile  float yaw_usart_angle;
extern volatile  float yaw_usart_temp;
extern volatile  float last_yaw_usart_temp;

extern float gyro_usart_y;
extern float gyro_usart_z;

void Usart_Imu_Data_Process(const uint8_t *ucRxBuffer);

#endif 