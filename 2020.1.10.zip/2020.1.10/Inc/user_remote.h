#include "stm32f4xx_hal.h"
#include "RM_LIB.h"
#include "user_PID.h"
#define STICK_TO_CHASSIS_SPEED_REF_FACT     12.0f
#define STICK_TO_PITCH_ANGLE_INC_FACT       0.0015f
#define STICK_TO_YAW_ANGLE_INC_FACT         0.0025f
#define STICK_TO_CHASSIS_ROTATE_FACT				6.0f
#define MOUSE_TO_PITCH_ANGLE_INC_FACT 		0.06f
#define MOUSE_TO_YAW_ANGLE_INC_FACT 	   	0.08f

#define FRICTION_WHEEL_OFF 0  //摩擦轮关闭
#define FRICTION_WHEEL_ON 1   //摩擦轮在运行
//typedef enum
//{
//	FRICTION_WHEEL_OFF = 0,  //摩擦轮关闭
//	FRICTION_WHEEL_ON = 1,   //摩擦轮在运行
//}FrictionWheelState_e;

extern float Yaw_Angle_Init;
extern ChassisSpeed_Ref_t ChassisSpeed_Ref;
extern PTZAngle_Ref_t PTZAngle_Ref;

