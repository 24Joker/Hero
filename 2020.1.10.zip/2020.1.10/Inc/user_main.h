#include "stm32f4xx_hal.h"
#include "RM_Lib.h"

#define BUFLEN1 30
#define BUFLEN2 40
#define MINIPC_BUFFLEN 10
#define PTZ_Yaw_Mid 1285
#define PTZ_Pitch_Mid 2809
#define PTZ_Pitch_Max 3502
#define PTZ_Pitch_Min 2420

extern uint8_t usart1_dma_bf[BUFLEN1];
extern uint8_t usart2_dma_bf[BUFLEN2];
extern uint8_t camera_buff[MINIPC_BUFFLEN];

extern uint8_t Chassis_Buff[8];
extern uint8_t PTZ_Buff[8];
extern uint8_t Toggle_Buff[8];

extern RM3508_TypeDef Rx_Chassis_RM3508_ID1;
extern RM3508_TypeDef Rx_Chassis_RM3508_ID2;
extern RM3508_TypeDef Rx_Chassis_RM3508_ID3;
extern RM3508_TypeDef Rx_Chassis_RM3508_ID4;
extern RM3508_TypeDef Rx_Toggle_RM3508;
extern RM3510_TypeDef Rx_Friction_RM3510_Left;
extern RM3510_TypeDef Rx_Friction_RM3510_Right;
extern GM6020_TypeDef Rx_PTZ_Yaw_GM6020;
extern GM6020_TypeDef Rx_PTZ_Pitch_GM6020;
