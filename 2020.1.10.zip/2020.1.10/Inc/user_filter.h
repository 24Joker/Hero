#include "RM_LIB.h"
#include "stm32f4xx_hal.h"
extern kalman_filter_init_t Ch2_Init;
extern kalman_filter_init_t Kalman_Yaw_PTZ_AimAuto;
extern kalman_filter_init_t Kalman_Pitch_PTZ_AimAuto;
extern kalman_filter_init_t Kalman_Distance_AimAuto;


extern speed_calc_data_t Yaw_PTZ_calculate_Speed;
extern speed_calc_data_t Pitch_PTZ_calculate_Speed;
extern speed_calc_data_t Distance_PTZ_calculate_Speed;

void All_Kalman_Filter_Init();
