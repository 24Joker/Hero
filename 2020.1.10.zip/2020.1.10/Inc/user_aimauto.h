#include "RM_LIB.h"
#include "stm32f4xx_hal.h"
#include "user_filter.h"
#include "user_remote.h"

typedef struct                //�����ӳٽṹ��
{
	float gimbal_attitude_archive[200];
	uint8_t archive_index;
  uint8_t get_index;
} Data_delay_t;

extern uint32_t Time3_AimAuto;
extern uint8_t AimAuto_Flag;
extern int16_t yaw_rec,pitch_rec,dist_rec,thelta_raw;
extern float yaw_speed_raw, distance_speed_raw, pitch_speed_raw;
extern float y_angle, p_angle, yaw_delay, y_angle_offset, p_angle_offset, yaw_speed_filter, pitch_speed_filter, distance_filter;
extern float pitch_delay;
extern float yaw_filter, pitch_filter , y_anglesave , p_anglesave ;
extern float Camera_Yaw , Camera_Pitch, dist_raw;



extern Data_delay_t Yaw_angle_delay;
extern Data_delay_t Pitch_angle_delay;

void AimAuto_Process(uint8_t* aimautobuff);
void DATA_delay(Data_delay_t *D,float delay_object,float delay_index);
void aimauto_control(void);

